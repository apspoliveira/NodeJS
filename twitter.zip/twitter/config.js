module.exports = {
    consumer_key : 'XY0eS1zl7TW7g3FEJAfhN147M',
    consumer_secret : '5x3lTCwffMBwOsp4P6d9Ga0QmLP84vUqpPCqQgcBbYrUfHhk3r',
    access_token : '915272193663172608-gF4eoJCqQwZ2klT8ll2ZBzfOR1qc6Ho',
    access_token_secret : 'zptZ9HzAt25SsWPIjDy7A37lUKbFBG3MmZp4UklEYdvtl'
}