console.log("MediumBot ready!");
console.log();

var Twit = require("twit");
var config = require("./config");

console.log(config);
console.log();

var T = new Twit(config);

function tweetStatus(message){

    var tweet = {
        status: message
    }

    T.post('statuses/update', tweet, tweeted);

    function tweeted(err, data, response) {
        if(err) {
            console.log("Something went wrong!");
            console.log(err);
            console.log();
        }
        else {
            console.log("Success! the post has been Tweeted!")
        };
    }
}

function tweetEvent(tweetMSG){
    var fs = require('fs');
    var json = JSON.stringify(tweetMSG, null, 2);
    fs.writeFile("tweets.json", json);

    var replyTo = tweetMSG.in_reply_to_screen_name;
    var text = tweetMSG.text;
    var from = tweetMSG.user.screen_name;

    console.log(replyTo + from);
    console.log(text);
    console.log();

    if(replyTo == 'RemBot' || replyTo == 'Remyx') {
        var newTweet = ('@' + from + "Thank you for mentioning me! #MediumRocks");
        tweetStatus(newTweet);
    }
};

function followed(eventMessage) {
    var name = eventMessage.source.name;
    var screenName = eventMessage.source.screen_name;
    tweetStatus ('@' + screenName + 'Thank you for following me!');
};

//tweetStatus("Hello World!");

//var stream = T.stream('PortugalTelecom');
setInterval(tweetStatus, 10000);

//stream.on('follow', followed);
//stream.on('tweet', tweetEvent);